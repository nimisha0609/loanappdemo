import React from "react";

interface SubTabsProps {
  activeSubTab: string;
  setActiveSubTab: (tab: string) => void;
}

const SubTabs: React.FC<SubTabsProps> = ({ activeSubTab, setActiveSubTab }) => {
  const subTabs = [
    "About",
    "Name and Address",
    "Contact Information",
    "Identification",
  ];
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      {subTabs.map((tab) => (
        <button
          key={tab}
          onClick={() => setActiveSubTab(tab)}
          className={`px-3 py-1 border rounded ${
            activeSubTab === tab
              ? "bg-blue-100 text-blue-700 font-medium"
              : "bg-white text-gray-600"
          }`}
        >
          {tab}
        </button>
      ))}
    </div>
  );
};

export default SubTabs;
