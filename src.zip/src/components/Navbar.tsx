import React, { useState } from "react";

const Navbar: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <nav className="bg-white shadow px-6 py-4 flex justify-between items-center relative">
      <div className="text-xl font-bold text-blue-600">FIS Profile</div>
      <div className="relative">
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="flex items-center space-x-2 focus:outline-none"
        >
          <span className="text-sm font-medium text-gray-700 hover:underline">
            Nimmy Sunny
          </span>
          <img
            src="https://avatar.iran.liara.run/public/96"
            alt="Profile"
            className="w-8 h-8 rounded-full border"
          />
        </button>

        {menuOpen && (
          <div className="absolute right-0 mt-2 w-48 bg-white border rounded shadow-lg z-10">
            <ul className="py-2 text-sm text-gray-700">
              <li>
                <button className="block w-full text-left px-4 py-2 hover:bg-gray-100">
                  View Profile
                </button>
              </li>
              <li>
                <button className="block w-full text-left px-4 py-2 hover:bg-gray-100">
                  Settings
                </button>
              </li>
              <li>
                <hr className="my-1" />
                <button className="block w-full text-left px-4 py-2 hover:bg-red-100">
                  Logout
                </button>
              </li>
            </ul>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
