import React from "react";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="text-center text-sm text-gray-400 py-4 border-t mt-6">
      &copy; {currentYear} FIS Global. All rights reserved.
    </footer>
  );
};

export default Footer;
