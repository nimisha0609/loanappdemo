import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Tabs from "./components/Tabs";
import SubTabs from "./components/SubTabs";
import ProfileSections from "./components/ProfileSections";
import Footer from "./components/Footer";

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("Personal");
  const [activeSubTab, setActiveSubTab] = useState<string>("About");

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Navbar />
      <div className="flex-grow p-6 max-w-6xl mx-auto w-full">
        <div className="bg-white p-6 rounded-2xl shadow">
          <h1 className="text-2xl font-bold mb-4">Profile</h1>
          <div className="flex items-center space-x-4 mb-4">
            <img
              src="https://avatar.iran.liara.run/public/96"
              alt="profile"
              className="w-16 h-16 rounded-full"
            />
            <div>
              <h2 className="text-lg font-semibold">NIMMY SUNNY</h2>
            </div>
          </div>
          <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
          {activeTab === "Personal" && (
            <SubTabs
              activeSubTab={activeSubTab}
              setActiveSubTab={setActiveSubTab}
            />
          )}
          <ProfileSections
            activeTab={activeTab}
            subTab={activeTab === "Personal" ? activeSubTab : "General"}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default App;
