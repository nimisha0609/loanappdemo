import React, { useState, useEffect } from "react";

const Section = ({ title, fields }) => {
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState(fields);

  // This keeps formData in sync when props.fields changes
  useEffect(() => {
    setFormData(fields);
    setEditing(false); // Optional: also turn off editing when switching sections
  }, [fields]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="bg-gray-50 p-4 rounded-xl border mb-4">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-md font-semibold">{title}</h3>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setEditing(!editing)}
            className="text-sm text-blue-600"
          >
            {editing ? "Save" : "Edit"}
          </button>
          <button className="text-sm text-red-600">Delete</button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(formData).map(([key, value]) => (
          <div key={key}>
            <label className="block text-sm font-medium text-gray-600">
              {key.replace(/_/g, " ")}:
            </label>
            {editing ? (
              <input
                name={key}
                value={value}
                onChange={handleChange}
                className="mt-1 block w-full border rounded px-2 py-1 text-sm"
              />
            ) : (
              <p className="mt-1 text-sm">{value || "-"}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const ProfileSections = ({ activeTab, subTab }) => {
  const sections = {
    Personal: {
      About: [
        {
          title: "Overview",
          fields: { US_Citizen: "Yes", Birth_Date: "XX/XX/1990" },
        },
        {
          title: "Credit",
          fields: {
            Credit_History: "",
            Risk_Rating: "",
            Credit_Rating: "",
            Risk_Assessment: "",
            Profitability_Score: "",
            Current_Profitability: "",
            Rolling_12_Month: "",
            "Year-To-Date": "",
            Bankruptcy: "0 - No bankruptcy",
          },
        },
        {
          title: "Demographics",
          fields: {
            Maiden_Name: "",
            Occupation: "",
            Description: "EMPLOYEDFT",
            "Position/Title": "",
            "Full/Part Time": "Employed Full-Time",
            Income: "",
            "Employer/School": "FIS",
            "Employer/School Date": "",
            Education: "",
            Secondary_Employer: "",
          },
        },
      ],
      "Name and Address": [
        {
          title: "Current Address",
          fields: {
            Street: "CHURCH ST",
            "City/State/Zip": "MIAMI, FL, 32818",
            Country: "UNITED STATES",
            Effective: "02/12/2019",
          },
        },
        {
          title: "Previous Address",
          fields: { Previous: "No Previous addresses" },
        },
        { title: "Future Address", fields: { Future: "No Future addresses" } },
        {
          title: "Alias Information",
          fields: { Alias: "No Alias Information" },
        },
      ],
      "Contact Information": [
        {
          title: "Non-North American Phone",
          fields: { NonNorthAmericanNumber: "" },
        },
        {
          title: "Email",
          fields: {
            Email_Type: "HME - HOME",
            Email_Address: "NIMMY.SUNNY@GMAIL.COM",
            Effective_Date: "02/12/2020",
          },
        },
        {
          title: "eConsent",
          fields: { Enrolled: "No, Customer is not enrolled in eConsent" },
        },
        {
          title: "Phone",
          fields: {
            Additional_Phone_Type: "HME - HOME",
            Phone_Number: "(312) 121-2121",
            Extension: "",
            Effective_Date: "02/12/2019",
          },
        },
        {
          title: "Marketing Solicitation Preferences",
          fields: { Solicit: "", Mail_Preference: "", Email_Preference: "" },
        },
      ],
      Identification: [
        {
          title: "Overview",
          fields: { Mothers_Maiden_Name: "", Password: "", Password_Clue: "" },
        },
        {
          title: "Documentary",
          fields: {
            ID_Type: "000",
            ID_Number: "S12345677",
            Issued_Date: "01/02/2000",
            Expiration_Date: "01/02/2020",
            Issuing_Entity: "FL",
            Issuing_Location: "FL",
          },
        },
      ],
    },
    Additional: {
      General: [
        {
          title: "Bank Info",
          fields: {
            Bank_Name: "",
            Account_Type: "",
            Routing_Number: "",
            Account_Number: "",
          },
        },
        {
          title: "Customer Codes",
          fields: { Code1: "", Code2: "", Code3: "" },
        },
        {
          title: "Miscellaneous",
          fields: { Notes: "", Preferences: "", Tags: "" },
        },
      ],
    },
    "Documents Archive": {
      General: [
        {
          title: "No Documents Available",
          fields: {
            Message: "There are no Documents to display at the moment",
          },
        },
      ],
    },
  };

  const tabSections = sections[activeTab]?.[subTab || "General"];

  return (
    <div>
      {tabSections?.map((section, idx) => (
        <Section key={idx} title={section.title} fields={section.fields} />
      )) || <p>No data available for this section.</p>}
    </div>
  );
};

export default ProfileSections;
