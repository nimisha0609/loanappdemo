const Footer = () => {
  return (
    <footer className="text-center text-sm text-gray-400 py-4 border-t mt-6">
      &copy; 2025 FIS Global. All rights reserved.
    </footer>
  );
};

export default Footer;
